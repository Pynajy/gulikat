from django.contrib import admin
from lk.models import (
    Profile,
    Adress,
)


admin.site.register(Profile)
admin.site.register(Adress)