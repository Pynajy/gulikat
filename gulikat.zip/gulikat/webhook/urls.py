from django.urls import path, include

# from webhook.views import (
#     AddPayment
# )

urlpatterns = [
    # path('succeeded', AddPayment.as_view(), name='AddPayment'),
]